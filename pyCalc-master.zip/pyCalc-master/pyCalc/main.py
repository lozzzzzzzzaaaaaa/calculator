#! /usr/bin/env python

from gui import TkGUI

app = TkGUI()
app.run()