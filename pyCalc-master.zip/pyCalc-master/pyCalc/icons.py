# Base64 encoded icon.gif
# utf-8 character set

icon_string = """R0lGODlhEAAQAMZCADZyyzhzzDp0zDt1zD94zUB5zUB5zkF5zkJ6zkN6zkN7zkN7z0R7zkR7z0R8
z0V8z0d+0Eh+0Eh/0Eh/0Ul/0Ep/0E6D0k+D0lCE0lSH01WI01iK1FmK1VmL1FqL1VuM1WOR12aT
2GaU2GeU2GiU2GyX2XCb23Sd3HSe3Hae3Haf3Hif3Hyi3Xyj3X2j3n6k3n+l3n+l34Cm3oOn34Oo
34So4Ims4Z675sTW8MXW8NHf9N3n9uDp9+bt+Onw+vP2/Pf6/fz9/v//////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////yH+
EUNyZWF0ZWQgd2l0aCBHSU1QACH5BAEKAH8ALAAAAAAQABAAAAeWgH+Cg4SFgw+IiYqIhA8NB5CR
kIyDDBgxLpmaMRAOhAQvBgqjowUhHQmfLAuQDRUSCCQbqYMELBM2MxcgHweytIK2CyY1EREWBiOz
qg4sKw0yFCUwHgiqETQwHCo5QkI3A58vEYgYIkI4PD/WgwoZKScoJy9APkE7AI0OCfwJDS09dGhg
J2gRIgMBBCx40MjgIkMQCwUCADs="""